#ifndef _MAIN_H
#define _MAIN_H
#include "main.h" 
#endif

void Pulse_Start();
void Pulse_Stop();			